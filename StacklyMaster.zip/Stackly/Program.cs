﻿using System;
using System.IO;
using System.Collections.Generic;

namespace Stackly
{
    class Program
    {
        static void Main(string[] args)
        {
            string path;
            if(args.Length == 1) path = args[0];
            else
            {
                Console.WriteLine("Please input the path of the programm to run");
                path = Console.ReadLine();
            }
            Console.Clear();
            Interpreter I = new Interpreter(path);
            I.interpret();
        }
    }
    class Interpreter
    {
        private string[][] code;
        private int pc;

        private Stack<int> A;
        private Stack<int> B;
        private Stack<int> C;

        public void interpret()
        {
            while(pc < code.Length)
            {
                switch (code[pc][0])
                {
                    #region Misc
                    case "stp":
                        pc = code.Length;
                        break;
                    #endregion
                    #region I/O
                    case "outn":
                        if (code[pc][1] == "a")
                        {
                            Console.Write(A.Pop());
                        }
                        else if (code[pc][1] == "b")
                        {
                            Console.Write(B.Pop());
                        }
                        else if (code[pc][1] == "c")
                        {
                            Console.Write(C.Pop());
                        }
                        break;
                    case "outc":
                        if (code[pc][1] == "a")
                        {
                            Console.Write((char)A.Pop());
                        }
                        else if (code[pc][1] == "b")
                        {
                            Console.Write((char)B.Pop());
                        }
                        else if (code[pc][1] == "c")
                        {
                            Console.Write((char)C.Pop());
                        }
                        break;
                    case "inn":
                        if (code[pc][1] == "a")
                        {
                            A.Push(int.Parse(Console.ReadLine()));
                        }
                        else if (code[pc][1] == "b")
                        {
                            B.Push(int.Parse(Console.ReadLine()));
                        }
                        else if (code[pc][1] == "c")
                        {
                            C.Push(int.Parse(Console.ReadLine()));
                        }
                        break;
                    case "inc":
                        if (code[pc][1] == "a")
                        {
                            A.Push((int)Console.ReadKey().KeyChar);
                        }
                        else if (code[pc][1] == "b")
                        {
                            B.Push((int)Console.ReadKey().KeyChar);
                        }
                        else if (code[pc][1] == "c")
                        {
                            C.Push((int)Console.ReadKey().KeyChar);
                        }
                        break;
                    #endregion
                    #region Stack Manipulation
                    #region General
                    case "rmv":
                        if (code[pc][1] == "a")
                        {
                            A.Pop();
                        }
                        else if (code[pc][1] == "b")
                        {
                            B.Pop();
                        }
                        else if (code[pc][1] == "c")
                        {
                            C.Pop();
                        }
                        break;
                    case "push":
                        if(code[pc][1] == "a")
                        {
                            A.Push(int.Parse(code[pc][2]));
                        }
                        else if(code[pc][1] == "b")
                        {
                            B.Push(int.Parse(code[pc][2]));
                        }
                        else if(code[pc][1] == "c")
                        {
                            C.Push(int.Parse(code[pc][2]));
                        }
                        break;
                    case "dbl":
                        if (code[pc][1] == "a")
                        {
                            A.Push(A.Peek());
                        }
                        else if (code[pc][1] == "b")
                        {
                            B.Push(B.Peek());
                        }
                        else if (code[pc][1] == "c")
                        {
                            C.Push(C.Peek());
                        }
                        break;
                    case "pshc":
                        if (code[pc][1] == "a")
                        {
                            A.Push(A.Count);
                        }
                        else if (code[pc][1] == "b")
                        {
                            B.Push(B.Count);
                        }
                        else if (code[pc][1] == "c")
                        {
                            C.Push(C.Count);
                        }
                        break;
                    #endregion
                    #region Datatransfair
                    case "pop":
                        if (code[pc][1] == "a")
                        {
                            if(code[pc][2] == "b")
                            {
                                B.Push(A.Pop());
                            }
                            else if(code[pc][2] == "c")
                            {
                                C.Push(A.Pop());
                            }
                        }
                        else if (code[pc][1] == "b")
                        {
                            if (code[pc][2] == "a")
                            {
                                A.Push(B.Pop());
                            }
                            else if (code[pc][2] == "c")
                            {
                                C.Push(B.Pop());
                            }
                        }
                        else if (code[pc][1] == "c")
                        {
                            if (code[pc][2] == "a")
                            {
                                A.Push(C.Pop());
                            }
                            else if (code[pc][2] == "b")
                            {
                                B.Push(C.Pop());
                            }
                        }
                        break;
                    case "popa":
                        if (code[pc][1] == "a")
                        {
                            if (code[pc][2] == "b")
                            {
                                A.Push(A.Pop() + B.Pop());
                            }
                            else if (code[pc][2] == "c")
                            {
                                A.Push(A.Pop() + C.Pop());
                            }
                        }
                        else if (code[pc][1] == "b")
                        {
                            if (code[pc][2] == "a")
                            {
                                B.Push(B.Pop() + A.Pop());
                            }
                            else if (code[pc][2] == "c")
                            {
                                B.Push(B.Pop() + C.Pop());
                            }
                        }
                        else if (code[pc][1] == "c")
                        {
                            if (code[pc][2] == "a")
                            {
                                C.Push(C.Pop() + A.Pop());
                            }
                            else if (code[pc][2] == "b")
                            {
                                C.Push(C.Pop() + B.Pop());
                            }
                        }
                        break;
                    case "pops":
                        if (code[pc][1] == "a")
                        {
                            if (code[pc][2] == "b")
                            {
                                A.Push(A.Pop() - B.Pop());
                            }
                            else if (code[pc][2] == "c")
                            {
                                A.Push(A.Pop() - C.Pop());
                            }
                        }
                        else if (code[pc][1] == "b")
                        {
                            if (code[pc][2] == "a")
                            {
                                B.Push(B.Pop() - A.Pop());
                            }
                            else if (code[pc][2] == "c")
                            {
                                B.Push(B.Pop() - C.Pop());
                            }
                        }
                        else if (code[pc][1] == "c")
                        {
                            if (code[pc][2] == "a")
                            {
                                C.Push(C.Pop() - A.Pop());
                            }
                            else if (code[pc][2] == "b")
                            {
                                C.Push(C.Pop() - B.Pop());
                            }
                        }
                        break;
                    case "popm":
                        if (code[pc][1] == "a")
                        {
                            if (code[pc][2] == "b")
                            {
                                A.Push(A.Pop() * B.Pop());
                            }
                            else if (code[pc][2] == "c")
                            {
                                A.Push(A.Pop() * C.Pop());
                            }
                        }
                        else if (code[pc][1] == "b")
                        {
                            if (code[pc][2] == "a")
                            {
                                B.Push(B.Pop() * A.Pop());
                            }
                            else if (code[pc][2] == "c")
                            {
                                B.Push(B.Pop() * C.Pop());
                            }
                        }
                        else if (code[pc][1] == "c")
                        {
                            if (code[pc][2] == "a")
                            {
                                C.Push(C.Pop() * A.Pop());
                            }
                            else if (code[pc][2] == "b")
                            {
                                C.Push(C.Pop() * B.Pop());
                            }
                        }
                        break;
                    case "popd":
                        if (code[pc][1] == "a")
                        {
                            if (code[pc][2] == "b")
                            {
                                A.Push(A.Pop() / B.Pop());
                            }
                            else if (code[pc][2] == "c")
                            {
                                A.Push(A.Pop() / C.Pop());
                            }
                        }
                        else if (code[pc][1] == "b")
                        {
                            if (code[pc][2] == "a")
                            {
                                B.Push(B.Pop() / A.Pop());
                            }
                            else if (code[pc][2] == "c")
                            {
                                B.Push(B.Pop() / C.Pop());
                            }
                        }
                        else if (code[pc][1] == "c")
                        {
                            if (code[pc][2] == "a")
                            {
                                C.Push(C.Pop() / A.Pop());
                            }
                            else if (code[pc][2] == "b")
                            {
                                C.Push(C.Pop() / B.Pop());
                            }
                        }
                        break;
                    case "popp":
                        if (code[pc][1] == "a")
                        {
                            if (code[pc][2] == "b")
                            {
                                A.Push(A.Pop() % B.Pop());
                            }
                            else if (code[pc][2] == "c")
                            {
                                A.Push(A.Pop() % C.Pop());
                            }
                        }
                        else if (code[pc][1] == "b")
                        {
                            if (code[pc][2] == "a")
                            {
                                B.Push(B.Pop() % A.Pop());
                            }
                            else if (code[pc][2] == "c")
                            {
                                B.Push(B.Pop() % C.Pop());
                            }
                        }
                        else if (code[pc][1] == "c")
                        {
                            if (code[pc][2] == "a")
                            {
                                C.Push(C.Pop() % A.Pop());
                            }
                            else if (code[pc][2] == "b")
                            {
                                C.Push(C.Pop() % B.Pop());
                            }
                        }
                        break;
                    #endregion
                    #endregion
                    #region PC Manipulation
                    #region Basic
                    case "goto":
                        pc = int.Parse(code[pc][1]) - 2;
                        break;
                    case "gsub":
                        if(code[pc][2] == "a")
                        {
                            A.Push(pc + 2);
                        }
                        else if(code[pc][2] == "b")
                        {
                            B.Push(pc + 2);
                        }
                        else if(code[pc][2] == "c")
                        {
                            C.Push(pc + 2);
                        }
                        pc = int.Parse(code[pc][1]) - 2;
                        break;
                    case "rtrn":
                        if (code[pc][1] == "a")
                        {
                            pc = A.Pop() - 2;
                        }
                        else if (code[pc][1] == "b")
                        {
                            pc = B.Pop() - 2;
                        }
                        else if (code[pc][1] == "c")
                        {
                            pc = C.Pop() - 2;
                        }
                        break;
                    #endregion
                    #region If's
                    case "gifz":
                        if(code[pc][2] == "a")
                        {
                            if(A.Pop() == 0)
                            {
                                pc = int.Parse(code[pc][1]) - 2;
                            }
                        }
                        else if (code[pc][2] == "b")
                        {
                            if (B.Pop() == 0)
                            {
                                pc = int.Parse(code[pc][1]) - 2;
                            }
                        }
                        else if (code[pc][2] == "c")
                        {
                            if (C.Pop() == 0)
                            {
                                pc = int.Parse(code[pc][1]) - 2;
                            }
                        }
                        break;
                    case "gifg":
                        if (code[pc][2] == "a")
                        {
                            if(code[pc][3] == "b")
                            {
                                if(A.Pop() > B.Pop())
                                {
                                    pc = int.Parse(code[pc][1]) - 2;
                                }
                            }
                            else if(code[pc][3] == "c")
                            {
                                if (A.Pop() > C.Pop())
                                {
                                    pc = int.Parse(code[pc][1]) - 2;
                                }
                            }
                        }
                        else if (code[pc][2] == "b")
                        {
                            if (code[pc][3] == "a")
                            {
                                if (B.Pop() > A.Pop())
                                {
                                    pc = int.Parse(code[pc][1]) - 2;
                                }
                            }
                            else if (code[pc][3] == "c")
                            {
                                if (B.Pop() > C.Pop())
                                {
                                    pc = int.Parse(code[pc][1]) - 2;
                                }
                            }
                        }
                        else if (code[pc][2] == "c")
                        {
                            if (code[pc][3] == "a")
                            {
                                if (C.Pop() > A.Pop())
                                {
                                    pc = int.Parse(code[pc][1]) - 2;
                                }
                            }
                            else if (code[pc][3] == "b")
                            {
                                if (C.Pop() > B.Pop())
                                {
                                    pc = int.Parse(code[pc][1]) - 2;
                                }
                            }
                        }
                        break;
                    #endregion
                    #endregion
                }
                pc++;
            }
        }

        public Interpreter(string path)
        {
            string[] commands = File.ReadAllLines(path);
            code = new string[commands.Length][];
            for(int i = 0; i < code.Length; i++)
            {
                code[i] = commands[i].Split(' ', StringSplitOptions.RemoveEmptyEntries);
                for(int o = 0; o < code[i].Length; o++)
                {
                    code[i][o] = code[i][o].ToLower();
                }
            }
            pc = 0;
            A = new Stack<int>();
            B = new Stack<int>();
            C = new Stack<int>();
        }
    }
}